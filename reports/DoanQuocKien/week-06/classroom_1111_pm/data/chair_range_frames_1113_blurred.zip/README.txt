Chair frames at taped distances, robot standing still (JetBot camera, 160 deg fisheye, 640x480), 2026-11-13, classroom, glossy tile floor.
Folders d0.60 ... d2.40 = the TRUE tape distance in metres (lens to the chair's front legs along the camera axis), as stated by the operator
(the recording script's own labels were shifted and were corrected afterwards: this zip uses the corrected distances).
12 frames per distance, 0.25 s apart (d0.90 keeps 5: the frames where a person stood against the chair were removed).
A person stood in the background: every person box is blurred; the chair itself was left intact.
Chair measurements (YOLOv8s, class 56, nearest chair = lowest floor contact; the largest box picks the background chairs on the right):
  width px: 0.6 m 204 (chair back leaves the picture, height unusable) | 0.9 m 138 | 1.2 m 112 | 1.5 m 94 | 1.8 m 77 | 2.4 m 61
  fit on 0.9-2.4 m: distance = 160.3 / width - 0.24, leave-one-out max error 0.05 m (one chair, front-on, left third of the picture).
  The floor contact of this chair is 'reflection_unresolved' with the configured detector on this floor (no ground distance).
Pose file for the day: calib/camera_pose_self_1113_1.json (pitch -9.12 deg). Details: reports/DoanQuocKien/week-06/classroom_1111_pm/README.md and data/chair_width_range_1113.json.
Not validated: one chair type, one day; the other-chair check used the 15/10 data (9 chairs, 7 within +/-0.16 m).
